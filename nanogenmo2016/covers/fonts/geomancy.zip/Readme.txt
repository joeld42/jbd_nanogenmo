This font is freeware for personal use. For commercial use, please contact us at info@onebyfourstudio.com

Feel free to distribute this font, but please don't distribute an edited version of this font. Do not rename this font. And definitely don't sell this font!

Thank you,
http://onebyfourstudio.com
Natasha Maria Fernandez-Fountain, One by Four � 2010